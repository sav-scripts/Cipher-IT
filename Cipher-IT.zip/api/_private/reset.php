<?php

include "./reset_login.php";
include "./reset_event.php";
include "./reset_participate.php";